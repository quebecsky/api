require('UIView', 'UIImage', 'BCMusicViewController', 'PopTransitionDelegate', 'BCConfirmDialogViewController')
require('UIColor')

defineClass('BCMainViewController', {
    registerErrorEvent: function() {
        self.registerLoginErrorEvent();
        self.registerRoomErrorEvent();
        console.log("========熱更 登入頁修改========");
    }
});

defineClass('BCRoomViewController', {
    viewDidLoad: function() {
        self.ORIGviewDidLoad();
        console.log("========熱更 測試========");
    }
});

// 實現新增 protocol, 語法與 OC 相同
defineClass('BCRoomsListViewController: BCBaseViewController<UIAlertViewDelegate>', ['testData', 'testTotalCount'], {
    // ['testData', 'testTotalCount'] , 新增兩個 property 至 class "BCRoomsListViewController"
    setupMoneyView: function() {
        self.ORIGsetupMoneyView()
        // 改變color, "colorWithHex" 擴充的function也可以使用
        var selfMonelyLabel = self.selfMonelyLabel();
        selfMonelyLabel.setColors([UIColor.colorWithHex('ffff00'), UIColor.colorWithRed_green_blue_alpha(1.0, 0.0, 0.0, 1.0)])
        // selfMonelyLabel.setColors([UIColor.colorWithHex('00ffff'), UIColor.colorWithRed_green_blue_alpha(1.0, 0.0, 0.0, 1.0)])
            
        console.log("========熱更 setupMoneyView========");
            
        // 自定義 ENUM 設定方式, 直接賦予值及給予自定義名稱皆可以達到效果
        selfMonelyLabel.setGradientDirection('BCGradientDirectionTopLeftToBottomRight')
        selfMonelyLabel.setGradientDirection(3)
            
        // 設定 image
        var scoreBgImage = self.scoreBgImage()
        scoreBgImage.setImage(UIImage.imageNamed('music'))
    },
    viewDidLoad: function() {
        // 原 class 有覆寫function viewDidLoad, 所以可呼叫 super().viewDidLoad()
        self.super().viewDidLoad();
        self.ORIGviewDidLoad()
            
        // 增加 property (id testData, testTotalCount)
        self.setTestData(["a", "b"])
        self.setTestTotalCount(2)
        console.log("========熱更 viewDidLoad setup new property========")
            
        // 使用Alert
        var alertView = require('UIAlertView').alloc().initWithTitle_message_delegate_cancelButtonTitle_otherButtonTitles("alert",
        "message", self, "cancel button", null)
        alertView.show()
    },
    viewDidAppear: function(animated) {
        //self.super().viewDidAppear();             // 原 class 並未覆寫function viewDidAppear, 所以不可呼叫 super().viewDidAppear()
            
        // 取得 JSPatch 新增的 property 值 (與viewDidLoad裡的是同一組設定)
        var data = self.testData()                  // 取得 property 值
        var totalCount = self.testTotalCount()
        console.log("========熱更 testTotalCount ==   " + totalCount + "========")
    }
});

