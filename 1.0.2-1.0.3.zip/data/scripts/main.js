require('UIView', 'UIImage', 'BCMusicViewController', 'PopTransitionDelegate', 'BCConfirmDialogViewController')
require('UIColor')

defineClass('BCMainViewController', {
    registerErrorEvent: function() {
        self.registerLoginErrorEvent();
        self.registerRoomErrorEvent();
        console.log("========熱更 登入頁修改========");
    }
});

defineClass('BCRoomViewController', {
    viewDidLoad: function() {
        self.ORIGviewDidLoad();
        console.log("========熱更 測試========");
    }
});

defineClass('BCRoomsListViewController: BCBaseViewController<UIAlertViewDelegate>', ['testData', 'testTotalCount'], {
    // ['testData', 'testTotalCount'] , 新增兩個 property 至 class "BCRoomsListViewController"
    setupMoneyView: function() {
        self.ORIGsetupMoneyView()
                
        // 改變color, "colorWithHex" 擴充的function也可以使用
        var selfMonelyLabel = self.selfMonelyLabel();
        // selfMonelyLabel.setColors([UIColor.colorWithHex('ffff00'), UIColor.colorWithRed_green_blue_alpha(1.0, 0.0, 0.0, 1.0)])
        selfMonelyLabel.setColors([UIColor.colorWithHex('00ffff'), UIColor.colorWithRed_green_blue_alpha(1.0, 0.0, 0.0, 1.0)])

        console.log("========熱更 setupMoneyView========");
    },
    viewDidLoad: function() {
        // 原 class 有覆寫function viewDidLoad, 所以可呼叫 super().viewDidLoad()
        self.super().viewDidLoad();                 
        self.ORIGviewDidLoad()
        },
        viewDidAppear: function(animated) {
            var data = self.testData()                  // 取得 property 值
            var totalCount = self.testTotalCount()
            console.log("========熱更 testTotalCount ==   " + totalCount + "========")
        }
});

